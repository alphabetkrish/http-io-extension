
const By = require('selenium-webdriver');

module.exports ={

    multiSelector: async function (driver, selectorList) {
        let locatorArray = selectorList.split('\n')
        return new Promise(async (resolve,rej) => {
        locatorArray.forEach(async (locatorValue) => {
                locatorValue=locatorValue.trim()
                let formattedString=await this.getLocator(locatorValue)
                let locType = formattedString.split("=");
                let type = locType.shift();
                let selector = (locType.join("="));
                let locator = await (`webdriver.By.${type.trim()}("${selector.trim()}")`);
                return driver.findElement((Function('"use strict";return (' + locator + ')')())).then((element)=>{
                resolve(locator)
                }).catch(()=>{
                  console.log('element not found with property => '+locator)
                 })               
               })
       })
    },
   getLocator: async function (locatorValue){
       
    return new Promise(async resolve => {
      
    if (locatorValue.startsWith(',') && locatorValue.endsWith(','))
    {
    return resolve(locatorValue.substring(1, locatorValue.length-1))
    }
    else if(locatorValue.startsWith(',')){
    
    return resolve(locatorValue.slice(1))
    }
    else if (locatorValue.endsWith(',')){
    return resolve(locatorValue.slice(0,-1))
    }
    // else {
      // return resolve(locatorValue)
    // }
})
},

timeout: 10000

}