const tests = {};
webdriver = require('selenium-webdriver');
tests["send KEY_ENTER"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=searchInput,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `id=searchInput,
`)))).then(element => {
    return element.clear().then(() => {
      return element.sendKeys(`selenium`);
    });
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=searchInput,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `id=searchInput,
`)))).then(element => {
    return element.sendKeys(Key["ENTER"]);
  });
}
tests["control flow if"] = async (driver, vars, opts = {}) => {
  vars["myVar"] = await driver.executeScript(`return "a"`);
  if (!!await driver.executeScript(`return (arguments[0] === "a")`, vars["myVar"])) {
    vars["output"] = await driver.executeScript(`return "a"`);
  } else if (!!await driver.executeScript(`return (arguments[0] === "b")`, vars["myVar"])) {
    vars["output"] = await driver.executeScript(`return "b"`);
  } else {
    vars["output"] = await driver.executeScript(`return "c"`);
  }
  expect(`${vars["output
"]}` == "a").toBeTruthy();
}
tests["control flow else if"] = async (driver, vars, opts = {}) => {
  vars["myVar"] = await driver.executeScript(`return "b"`);
  if (!!await driver.executeScript(`return (arguments[0] === "a")`, vars["myVar"])) {
    vars["output"] = await driver.executeScript(`return "a"`);
  } else if (!!await driver.executeScript(`return (arguments[0] === "b")`, vars["myVar"])) {
    vars["output"] = await driver.executeScript(`return "b"`);
  } else {
    vars["output"] = await driver.executeScript(`return "c"`);
  }
  expect(`${vars["output"]}` == "b").toBeTruthy();
}
tests["control flow else"] = async (driver, vars, opts = {}) => {
  vars["myVar"] = await driver.executeScript(`return "c"`);
  if (!!await driver.executeScript(`return (arguments[0] === "a")`, vars["myVar"])) {
    vars["output"] = await driver.executeScript(`return "a"`);
  } else if (!!await driver.executeScript(`return (arguments[0] === "b")`, vars["myVar"])) {
    vars["output"] = await driver.executeScript(`return "b"`);
  } else {
    vars["output"] = await driver.executeScript(`return "c"`);
  }
  expect(`${vars["output"]}` == "c").toBeTruthy();
}
tests["control flow do"] = async (driver, vars, opts = {}) => {
  vars["check"] = await driver.executeScript(`return 1`);
  do {
    vars["check"] = await driver.executeScript(`return arguments[0] + 1`, vars["check"]);
  } while (!!await driver.executeScript(`return (arguments[0] < 3)`, vars["check"]));
  expect(`${vars["check"]}` == "3").toBeTruthy();
}
tests["control flow times"] = async (driver, vars, opts = {}) => {
  vars["check"] = await driver.executeScript(`return 1`);
  const times = 2;
  for (let i = 0; i < times; i++) {
    vars["check"] = await driver.executeScript(`return arguments[0] + 1`, vars["check"]);
  }
  expect(`${vars["check"]}` == "3").toBeTruthy();
}
tests["control flow while"] = async (driver, vars, opts = {}) => {
  vars["check"] = await driver.executeScript(`return 1`);
  while (!!await driver.executeScript(`return (arguments[0] < 3)`, vars["check"])) {
    vars["check"] = await driver.executeScript(`return arguments[0] + 1`, vars["check"]);
  }
  expect(`${vars["check"]}` == "3").toBeTruthy();
}
tests["execute script"] = async (driver, vars, opts = {}) => {
  vars["blah"] = await driver.executeScript(`return true`);
  expect(`${vars["blah"]}` == "true").toBeTruthy();
  await driver.executeScript(`true`);
  console.log(`${vars.blah}
`);
}
tests["execute script array"] = async (driver, vars, opts = {}) => {
  vars["x"] = await driver.executeScript(`return [1,2,3]`);
  vars["y"] = await driver.executeScript(`return arguments[0][0] + 1`, vars["x"]);
  expect(`${vars["y"]}` == "2").toBeTruthy();
}
tests["execute script object"] = async (driver, vars, opts = {}) => {
  vars["x"] = await driver.executeScript(`return { x: 3 }`);
  vars["y"] = await driver.executeScript(`return arguments[0].x + 2`, vars["x"]);
  expect(`${vars["y"]}` == "5").toBeTruthy();
}
tests["execute script primitives"] = async (driver, vars, opts = {}) => {
  vars["bool"] = await driver.executeScript(`return true`);
  expect(`${vars["bool"]}` == "true").toBeTruthy();
  vars["float"] = await driver.executeScript(`return 3.14`);
  expect(`${vars["float"]}` == "3.14").toBeTruthy();
  vars["string"] = await driver.executeScript(`return "test"`);
  expect(`${vars["string"]}` == "test").toBeTruthy();
}
tests["check"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=something,
,name=something-else,
,linkText=number density,
,xpath=//a[contains(text(),'number density')],
,css=main .class > p a.link,
,xpath=(//a[contains(text(),'number line')])[2],
,(//a[contains(text(),'number line')])[2],
,//a[contains(text(),'number density')],
,//div[@id='mw-content-text']/div/p[2]/a[5],
,//a[contains(@href, '/wiki/Number_density')],
,//a[5],
,css=input,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `id=something,
,name=something-else,
,linkText=number density,
,xpath=//a[contains(text(),'number density')],
,css=main .class > p a.link,
,xpath=(//a[contains(text(),'number line')])[2],
,(//a[contains(text(),'number line')])[2],
,//a[contains(text(),'number density')],
,//div[@id='mw-content-text']/div/p[2]/a[5],
,//a[contains(@href, '/wiki/Number_density')],
,//a[5],
,css=input,
`)))).then(element => {
    return element.isSelected().then(selected => {
      if (!selected) {
        return element.click();
      }
    });
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=input,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=input,
`))))).resolves.toBeChecked();
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=input,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=input,
`)))).then(element => {
    return element.isSelected().then(selected => {
      if (selected) {
        return element.click();
      }
    });
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=input,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=input,
`))))).resolves.not.toBeChecked();
}
tests["click"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `linkText=Dropdown,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `linkText=Dropdown,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=h3,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=h3,
`))))).resolves.toHaveText(`Dropdown List`);
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `link=Dropdown,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `link=Dropdown,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=h3,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=h3,
`))))).resolves.toHaveText(`Dropdown List`);
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `partialLinkText=ropd,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `partialLinkText=ropd,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=h3,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=h3,
`))))).resolves.toHaveText(`Dropdown List`);
}
tests["click at"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=a,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=a,
`)))).then(element => {
    return element.click();
  });
}
tests["comment"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
}
tests["frames"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.switchTo().frame(0);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#tinymce,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=#tinymce,
`))))).resolves.toHaveText(`Your content goes here.`);
  await driver.get(BASE_URL);
  await driver.switchTo().frame(1);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#content,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=#content,
`))))).resolves.toHaveText(`MIDDLE`);
}
tests["select"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))).then(element => {
    return element.findElement(By.css(`*[value="1"]`)).then(option => {
      return option.click();
    });
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`))))).resolves.toHaveSelectedValue(`1`);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`))))).resolves.not.toHaveSelectedValue(`2`);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))).then(element => {
    return element.getAttribute("value").then(selectedValue => {
      return element.findElement(By.xpath('option[@value="' + selectedValue + '"]')).then(selectedOption => {
        return selectedOption.getText().then(selectedLabel => {
          return expect(selectedLabel).toBe(`Option 1`);
        });
      });
    });
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))).then(element => {
    return element.findElement(By.xpath(`//option[. = 'Option 2']`)).then(option => {
      return option.click();
    });
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`))))).resolves.toHaveSelectedValue(`2`);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`))))).resolves.not.toHaveSelectedValue(`1`);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `id=dropdown,
`)))).then(element => {
    return element.getAttribute("value").then(selectedValue => {
      return element.findElement(By.xpath('option[@value="' + selectedValue + '"]')).then(selectedOption => {
        return selectedOption.getText().then(selectedLabel => {
          return expect(selectedLabel).toBe(`Option 2`);
        });
      });
    });
  });
}
tests["send keys"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#username,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#username,
`)))).then(element => {
    return element.sendKeys(`tomsmith`);
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `xpath=//input[@id='password'],
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `xpath=//input[@id='password'],
`)))).then(element => {
    return element.sendKeys(`SuperSecretPassword!`, Key["ENTER"]);
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `id=flash,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `id=flash,
`))))).resolves.toHaveText(`You logged into a secure area!\n×`);
}
tests["store text"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#username,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#username,
`)))).then(element => {
    return element.sendKeys(`blah`);
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#username,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#username,
`)))).then(element => {
    return element.getAttribute("value").then(value => {
      return vars["aVar"] = value;
    });
  });
  console.log(`${vars.aVar}
`);
}
tests["submit"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#username,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#username,
`)))).then(element => {
    return element.sendKeys(`tomsmith`);
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#password,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#password,
`)))).then(element => {
    return element.sendKeys(`SuperSecretPassword!`);
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#login,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#login,
`)))).then(element => {
    return element.submit();
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=.flash.success,
`)))), multi.timeout);
  await expect(driver.findElements(eval(await (multi.multiSelector(driver, `css=.flash.success,
`))))).resolves.toBePresent();
}
tests["wait for element present"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#start button,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#start button,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish,
`)))), 5000);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish,
`))))).resolves.toHaveText(`Hello World!`);
}
tests["wait for element not present"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#checkbox-example button,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#checkbox-example button,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(until.stalenessOf(await driver.findElement(eval(await (multi.multiSelector(driver, `css=#checkbox,
`))))), 5000);
  await expect(driver.findElements(eval(await (multi.multiSelector(driver, `css=#checkbox,
`))))).resolves.not.toBePresent();
}
tests["wait for element visible"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#start button,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#start button,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(until.elementIsVisible(await driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish,
`))))), 5000);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish,
`))))).resolves.toHaveText(`Hello World!`);
}
tests["wait for element not visible"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#start button,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#start button,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(until.elementIsNotVisible(await driver.findElement(eval(await (multi.multiSelector(driver, `css=#loading,
`))))), 5000);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish,
`))))).resolves.toHaveText(`Hello World!`);
}
tests["wait for element editable (and not editable)"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example button,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example button,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(until.elementIsEnabled(await driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example input,
`))))), 5000);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example input,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example input,
`))))).resolves.toBeEditable();
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example button,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example button,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(until.elementIsDisabled(await driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example input,
`))))), 5000);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example input,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=#input-example input,
`))))).resolves.not.toBeEditable();
}
tests["locator fallback template"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=button,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=button,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#finis > h4,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=#finis > h4,
`)))).then(element => {
    return element.click();
  });
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish > h4,
`)))), multi.timeout);
  await expect(driver.findElement(eval(await (multi.multiSelector(driver, `css=#finish > h4,
`))))).resolves.toHaveText(`Hello World!`);
}
tests["confirmation dialog"] = async (driver, vars, opts = {}) => {
  await driver.get(BASE_URL);
  await driver.wait(async driver => await driver.findElement(eval(await (multi.multiSelector(driver, `css=li:nth-child(2) > button,
`)))), multi.timeout);
  await driver.findElement(eval(await (multi.multiSelector(driver, `css=li:nth-child(2) > button,
`)))).then(element => {
    return element.click();
  });
  await driver.switchTo().alert().then(alert => {
    return alert.getText().then(text => {
      return expect(text).toBe(`I am a JS Confirm
`);
    });
  });
  await driver.switchTo().alert().then(alert => {
    return alert.accept();
  });
}
tests["select window"] = async (driver, vars, opts = {}) => {
    await driver.get(BASE_URL);
    await driver.getWindowHandle().then(handle => {
          return vars["handle              "] = handle;});console.log(`${vars.handle}
              `);vars.__handles = await driver.getAllWindowHandles();await driver.wait(async driver => await driver.findElement(eval(await(multi.multiSelector(driver, `
              linkText = Elemental Selenium,
              `)))), multi.timeout);await driver.findElement(eval(await(multi.multiSelector(driver, `
              linkText = Elemental Selenium,
              `)))).then(element => {return element.click();});vars.newWindow = await utils.waitForWindow(driver, vars.__handles, 2000);await driver.getTitle().then(title => {return expect(title).toBe(`
              The Internet `);});await driver.switchTo().window(`
              $ {
                vars.handle
              }
              `);await driver.getTitle().then(title => {return expect(title).toBe(`
              The Internet `);});await driver.switchTo().window(`
              $ {
                vars.newWindow
              }
              `);await driver.getTitle().then(title => {return expect(title).toBe(`
              Elemental Selenium: Receive a Free, Weekly Tip on Using Selenium like a Pro `);});await driver.close();await driver.switchTo().window(`
              $ {
                vars.handle
              }
              `);await driver.getTitle().then(title => {return expect(title).toBe(`
              The Internet `);});await driver.close();};module.exports = tests;async function waitForWindow(driver, handles, timeout) {
  await driver.sleep(multi.timeout);
  const hndls = await driver.getAllWindowHandles();
  if (hndls.length > handles.length) {
    return hndls.find(h => (!handles.includes(h)));
  }
  throw new Error("New window did not appear before timeout");
}

module.exports = {
  waitForWindow
};// This file was generated using http io script gen
const multi = require("../utils/selector");
var driver = new webdriver.Builder().forBrowser('chrome').build();
global.Key = require('selenium-webdriver').Key;
global.URL = require('url').URL;
const BASE_URL = 'http://the-internet.herokuapp.com';
let vars = {};
jest.setTimeout(300000);
describe("all tests", () => {
  it("check", async () => {
    await tests["check"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("click", async () => {
    await tests["click"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("click at", async () => {
    await tests["click at"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("comment", async () => {
    await tests["comment"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("confirmation dialog", async () => {
    await tests["confirmation dialog"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow do", async () => {
    await tests["control flow do"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow else", async () => {
    await tests["control flow else"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow else if", async () => {
    await tests["control flow else if"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow if", async () => {
    await tests["control flow if"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow times", async () => {
    await tests["control flow times"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow while", async () => {
    await tests["control flow while"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("execute script", async () => {
    await tests["execute script"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("execute script array", async () => {
    await tests["execute script array"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("execute script object", async () => {
    await tests["execute script object"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("execute script primitives", async () => {
    await tests["execute script primitives"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("frames", async () => {
    await tests["frames"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("select", async () => {
    await tests["select"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("select window", async () => {
    await tests["select window"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("send KEY_ENTER", async () => {
    await tests["send KEY_ENTER"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("send keys", async () => {
    await tests["send keys"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("store text", async () => {
    await tests["store text"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("submit", async () => {
    await tests["submit"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element editable (and not editable)", async () => {
    await tests["wait for element editable (and not editable)"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element not present", async () => {
    await tests["wait for element not present"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element not visible", async () => {
    await tests["wait for element not visible"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element present", async () => {
    await tests["wait for element present"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element visible", async () => {
    await tests["wait for element visible"](driver, vars);
    expect(true).toBeTruthy();
  });
});
beforeEach(() => {
  vars = {};
});
afterEach(async () => (cleanup()));// This file was generated using http io script gen
const multi = require("../utils/selector");
var driver = new webdriver.Builder().forBrowser('chrome').build();
global.Key = require('selenium-webdriver').Key;
global.URL = require('url').URL;
const BASE_URL = 'http://the-internet.herokuapp.com';
let vars = {};
jest.setTimeout(300000);
describe("control flow", () => {
  it("control flow if", async () => {
    await tests["control flow if"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow else if", async () => {
    await tests["control flow else if"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow else", async () => {
    await tests["control flow else"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow do", async () => {
    await tests["control flow do"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow times", async () => {
    await tests["control flow times"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("control flow while", async () => {
    await tests["control flow while"](driver, vars);
    expect(true).toBeTruthy();
  });
});
beforeEach(() => {
  vars = {};
});
afterEach(async () => (cleanup()));// This file was generated using http io script gen
const multi = require("../utils/selector");
var driver = new webdriver.Builder().forBrowser('chrome').build();
global.Key = require('selenium-webdriver').Key;
global.URL = require('url').URL;
const BASE_URL = 'http://the-internet.herokuapp.com';
let vars = {};
jest.setTimeout(300000);
describe("smoke", () => {
  it("check", async () => {
    await tests["check"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("click", async () => {
    await tests["click"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("click at", async () => {
    await tests["click at"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("execute script", async () => {
    await tests["execute script"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("execute script array", async () => {
    await tests["execute script array"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("execute script primitives", async () => {
    await tests["execute script primitives"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("frames", async () => {
    await tests["frames"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("select", async () => {
    await tests["select"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("send keys", async () => {
    await tests["send keys"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("store text", async () => {
    await tests["store text"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("submit", async () => {
    await tests["submit"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("confirmation dialog", async () => {
    await tests["confirmation dialog"](driver, vars);
    expect(true).toBeTruthy();
  });
});
beforeEach(() => {
  vars = {};
});
afterEach(async () => (cleanup()));// This file was generated using http io script gen
const multi = require("../utils/selector");
var driver = new webdriver.Builder().forBrowser('chrome').build();
global.Key = require('selenium-webdriver').Key;
global.URL = require('url').URL;
const BASE_URL = 'http://the-internet.herokuapp.com';
let vars = {};
jest.setTimeout(300000);
describe("waits", () => {
  it("wait for element present", async () => {
    await tests["wait for element present"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element not present", async () => {
    await tests["wait for element not present"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element visible", async () => {
    await tests["wait for element visible"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element not visible", async () => {
    await tests["wait for element not visible"](driver, vars);
    expect(true).toBeTruthy();
  });
  it("wait for element editable (and not editable)", async () => {
    await tests["wait for element editable (and not editable)"](driver, vars);
    expect(true).toBeTruthy();
  });
});
beforeEach(() => {
  vars = {};
});
afterEach(async () => (cleanup()));