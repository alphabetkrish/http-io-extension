const multi=require("./utils/selector")

const StringEscape=require("js-string-escape")

//const utils = require("./utils.js");

const tests = {};

tests["search"] = async (driver, vars, opts = {}) => {
  
  await driver.get(BASE_URL);
  //await driver.manage().window().setRect({
    //width: 909,
    //height: 747
  //});


  // let varr=  await(multi.multiSelector(driver,        `css=.gLFyf,xpath=//input[@name='q'],xpath=//form[@id='tsf']/div[2]/div/div/div/div/input,xpath=//div/div/input`))
  // console.log(`varr==`+varr)

  //await  driver.findElement(eval(varr)).then(element => {

    


   await  driver.findElement(eval(await(multi.multiSelector(driver, `css=.gLFyf,xpath=//input[@name='q'],xpath=//form[@id='tsf']/div[2]/div/div/div/div/input,xpath=//div/div/input`)))).then(element => {
   return element.click();


  });
  //await getSelector(`name=q,css=.gLFyf,xpath=//input[@name='q'],xpath=//form[@id='tsf']/div[2]/div/div/div/div/input,xpath=//div/div/input`).then(()=>{})
  
 // await driver.wait(until.elementLocated(eval(loc)), 500000)
  //await getSelector(`css=.gLFyf,xpath=//input[@name='q'],xpath=//form[@id='tsf']/div[2]/div/div/div/div/input,xpath=//div/div/input`).then(()=>{})
  await driver.wait(until.elementLocated(eval(await (multi.multiSelector(driver, `name=q,css=.gLFyf,xpath=//input[@name='q'],xpath=//form[@id='tsf']/div[2]/div/div/div/div/input,xpath=//div/div/input`)))), multi.timeout);
  
  
  await driver.findElement(eval(await(multi.multiSelector(driver, `css=.gLFyf,xpath=//input[@name='q'],xpath=//form[@id='tsf']/div[2]/div/div/div/div/input,xpath=//div/div/input`)))).then(element => {
    return element.clear().then(() => {
      return element.sendKeys(`hello`);
    });
  });

  await driver.wait(until.elementLocated(eval(await(multi.multiSelector(driver,`css=.sbhl span,xpath=//form[@id='tsf']/div[2]/div/div[2]/div[2]/ul/li[2]/div/div/div/span,xpath=//li[2]/div/div/div/span`)))), configuration.timeout);
  await driver.findElement(await(multi.multiSelector(driver,`css=.sbhl span,xpath=//form[@id='tsf']/div[2]/div/div[2]/div[2]/ul/li[2]/div/div/div/span,xpath=//li[2]/div/div/div/span`))).then(element => {
    return element.click();
  });
}
module.exports = tests;async function waitForWindow(driver, handles, timeout) {
  await driver.sleep(timeout);
  const hndls = await driver.getAllWindowHandles();
  if (hndls.length > handles.length) {
    return hndls.find(h => (!handles.includes(h)));
  }
  throw new Error("New window did not appear before timeout");
}

module.exports = {
  waitForWindow
};// This file was generated using http io script gen
//const tests = require("./commons.js");
global.Key = require('selenium-webdriver').Key;

const {Builder, By, Key, until} = require('selenium-webdriver');  


webdriver = require('selenium-webdriver')

var driver = new webdriver.Builder().forBrowser('chrome').build()
//require('selenium-webdriver/chrome')
//require('chromedriver')


//const driver =  new Builder().forBrowser('chrome').build();
const URL = require('url').URL;
const BASE_URL = 'https://www.google.com';



//global.BASE_URL = configuration.baseUrl || 'https://www.google.com';
let vars = {};
jest.setTimeout(300000);



describe("Default Suite", function() {

  it("search", async function () {
    
    await  tests["search"](driver, vars);
    
    })
  })

beforeEach(() => {
  vars = {};
});
afterEach(async () => (cleanup()));


function getSelector (strLocator){
  
   let locatorArray=strLocator.split(',')
   let res=''
   locatorArray.forEach(function(value){
       
        
         
        const fragments = value.split("=");
        const type = fragments.shift();
        const selector = StringEscape(fragments.join("="));

          //console.log(`By.`+locationType[0]+`('`+locationType[1]+`')`)
          let locator=`By.`+type.trim()+`('`+selector.trim()+`')`
          driver.findElement(eval(locator)).then(function (){
          console.log(('from 100 '+locator))
          return eval(locator)
      })
       
    })
       //console.log('res='+res)
       //return (res.trim())
   
  // })
   
   }
